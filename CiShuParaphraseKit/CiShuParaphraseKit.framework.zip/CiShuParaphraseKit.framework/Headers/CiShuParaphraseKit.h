//
//  CiShuParaphraseKit.h
//  CiShuParaphraseKit
//
//  Created by 辞书_褚平欧 on 2020/3/16.
//  Copyright © 2020 辞书_cpo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CiShuParaphraseKit.
FOUNDATION_EXPORT double CiShuParaphraseKitVersionNumber;

//! Project version string for CiShuParaphraseKit.
FOUNDATION_EXPORT const unsigned char CiShuParaphraseKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CiShuParaphraseKit/PublicHeader.h>

#import "CiShuDictionaryManager.h"
#import "CiShuShowConfig.h"



